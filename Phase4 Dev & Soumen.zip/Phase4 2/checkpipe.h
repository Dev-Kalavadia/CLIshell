#ifndef CHECKPIPE_H
#define CHECKPIPE_H

int checkPipe(char* str1);

#endif
