#ifndef READ_H
#define READ_H

char *readInput();

#endif
